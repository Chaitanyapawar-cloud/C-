using System;

public class Program      //DO NOT change the class name
{
    public static void Main(string[] args)
    {   Console.WriteLine("Enter a string");
        string str1=Console.ReadLine();
        string[] st=str1.Split(" ");
        for(int i=st.Length-1;i>=0;i--)
        {
            Console.Write(st[i]+" ");
        }
    }
}

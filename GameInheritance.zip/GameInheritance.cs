using System;

public class Game
{
    public string Name{get;set;}
    public int MaxNumPlayers{get;set;}
    public override string ToString()
    {
        string op="Maximum number of players for "+Name+" is "+MaxNumPlayers;
        return op;
    }
}

public class GameWithTimeLimit: Game
{
    public int TimeLimit{get;set;}
    public override string ToString()
    {
        string ot="Time Limit for "+Name+" is "+TimeLimit+" minutes";
        Console.WriteLine(base.ToString());
        return ot;
    }
    
}
public class Program
{
    public static void Main(string[] args)
    {
        Game ob1 =new Game();
        Console.WriteLine("Enter a game");
        ob1.Name=Console.ReadLine();
        
        Console.WriteLine("Enter the maximum number of players");
        ob1.MaxNumPlayers=int.Parse(Console.ReadLine());
        
        GameWithTimeLimit ob2=new GameWithTimeLimit();
        Console.WriteLine("Enter a game");
        ob2.Name= Console.ReadLine();
        
        Console.WriteLine("Enter the maximum number of players");
        ob2.MaxNumPlayers=int.Parse(Console.ReadLine());
        
        Console.WriteLine("Enter the time limit in minutes");
        ob2.TimeLimit=int.Parse(Console.ReadLine());
        
        Console.WriteLine(ob1);
        Console.WriteLine(ob2);
        
    }
    
}
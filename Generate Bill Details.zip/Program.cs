using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProgFundamentals2  //DO NOT change the namespace name
{
    public class Program      //DO NOT change the class name
    {
        public static void Main(string[] args)     //DO NOT change the 'Main' method signature
        {
            Console.WriteLine("Enter the number of pizzas bought :");
            int pi=int.Parse(Console.ReadLine());
            Console.WriteLine("Enter the number of puffs bought :");
            int pu=int.Parse(Console.ReadLine());
            Console.WriteLine("Enter the number of pepsi bought :");
            int pe=int.Parse(Console.ReadLine());
             int copi=pi*200;
             int copu=pu*40;
             int cope=pe*120;
             int tot=copi+cope+copu;
             double gst=tot*0.12;
             double cess=tot*0.05;
             
             Console.WriteLine("Bill Details\n");
             Console.WriteLine("Cost of Pizzas :"+copi);
             Console.WriteLine("Cost of Puffs :"+copu);
             Console.WriteLine("Cost of Pepsis :"+cope);
             Console.WriteLine("GST 12% : "+gst);
             Console.WriteLine("CESS 5% : "+cess);
             Console.WriteLine("Total Price :"+tot);
             
             
            
           
        }
    }
}

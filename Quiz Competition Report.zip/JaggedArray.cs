using System;


namespace JaggedArray      //DO NOT Change the namespace name
{
    public class Program    //DO NOT Change the class name
    {
        public static void Main(string[] args)    //DO NOT change the method signature
        {
	       Console.WriteLine("Enter the number of teams:");
	       int teams=int.Parse(Console.ReadLine());
	       int [][]arr=new int[teams][];
	       for(int i=0;i<teams;i++)
	       {
	           Console.WriteLine("No.of attempts for team "+(i+1)+":");
	           int a=int.Parse(Console.ReadLine());
	           arr[i]=new int[a];
	       }
	       for(int k=0;k<teams;k++)
	       {
	           Console.WriteLine("Enter the score for team "+(k+1)+":");
	           for(int j=0;j<arr[k].Length;j++)
	           {
	               arr[k][j]=int.Parse(Console.ReadLine());
	           }
	       }
	       Console.WriteLine(GetTotalScore(arr));
        }
        
        public static String GetTotalScore(int[][]array)        //DO NOT change the method signature
        {
            int []ar=new int[array.Length];
            for(int k=0;k<array.Length;k++)
            {   int sum=0;
                for(int j=0;j<array[k].Length;j++)
                {
                     
                    sum=sum+array[k][j];
                    
                }
                ar[k]=sum;
            }
            string str="";
            for(int s=0;s<ar.Length;s++)
            {
                str=str+"Team "+(s+1)+" Total Score is "+ar[s]+". ";
            }
            return str;
        }

    }
}
